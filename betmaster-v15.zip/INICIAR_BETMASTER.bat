@echo off
REM ============================================================
REM  BetMaster AI - Arranque con API de football-data.org
REM  1) Crea tu clave GRATIS en https://www.football-data.org/client/register
REM  2) Pegala cuando el script la pida (la pide una sola vez por sesion)
REM ============================================================
cd /d "%~dp0"

if "%FOOTBALL_DATA_API_KEY%"=="" (
    echo Configura tu clave de football-data.org para datos EN VIVO.
    set /p FOOTBALL_DATA_API_KEY="Pega tu clave aqui: "
)

set PORT=8080
echo.
echo Iniciando BetMaster AI en http://localhost:8080 ...
start "" http://localhost:8080
python server.py
pause
