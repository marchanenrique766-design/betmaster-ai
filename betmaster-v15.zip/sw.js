/* BetMaster AI · Service Worker */
var CACHE='betmaster-v7';
self.addEventListener('install',function(e){
  e.waitUntil(caches.open(CACHE).then(function(c){
    return c.addAll(['./','./index.html','./manifest.webmanifest','./assets/ai-football-hero.jpg','./icons/icon-192.png','./icons/icon-512.png'])
  }).then(function(){return self.skipWaiting()}));
});
self.addEventListener('activate',function(e){
  e.waitUntil(caches.keys().then(function(ks){
    return Promise.all(ks.map(function(k){return k===CACHE?null:caches.delete(k)}))
  }).then(function(){return self.clients.claim()}));
});
self.addEventListener('fetch',function(e){
  if(e.request.method!=='GET')return;
  var url=e.request.url;
  if(url.indexOf('/api/')>=0){e.respondWith(fetch(e.request).catch(function(){return new Response('{"ok":false,"error":"offline"}',{headers:{'Content-Type':'application/json'}})}));return}
  e.respondWith(caches.match(e.request).then(function(r){
    if(r)return r;
    return fetch(e.request).then(function(res){
      var cl=res.clone();
      caches.open(CACHE).then(function(c){c.put(e.request,cl)});
      return res;
    }).catch(function(){return caches.match('./index.html')});
  }));
});
