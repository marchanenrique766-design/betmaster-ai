# ⚙️ CONFIGURAR LA API · BetMaster AI

Tu app usa **football-data.org** como proveedor de datos reales.
La clave vive solo en el servidor (`server.py`) y nunca se expone en el navegador.

## 1) Crear la clave (gratis, 2 minutos)

1. Entra a: https://www.football-data.org/client/register
2. Regístrate (plan **Free**).
3. Copia tu clave de: https://www.football-data.org/email
   (llega por correo tras registrarte).

## 2) Arrancar la app

**Opción A — Windows (recomendada):**
Doble clic a `INICIAR_BETMASTER.bat` → pega la clave cuando la pida.
(Listo. La pide una vez por sesión; el navegador se abre solo en `http://localhost:8080`)

**Opción B — Manual (PowerShell):**
```powershell
cd betmaster-ai-zen-v2
$env:FOOTBALL_DATA_API_KEY = "TU_CLAVE_AQUI"
python server.py
```

**Opción C — Linux/Mac:**
```bash
export FOOTBALL_DATA_API_KEY="TU_CLAVE_AQUI"
python3 server.py
```

## 3) ¿Cómo sé que quedó conectado?

En la app, arriba junto al logo aparece la píldora de estado:

| Píldora | Significado |
|---|---|
| 🟢 **EN VIVO · football-data.org** | Datos reales activos |
| 🟡 **MODO DEMO** | Sin clave o sin servidor (usa el motor demo) |
| 🔴 **API no respondió** | Clave inválida, sin internet o límite de peticiones |

Con 🟢 las ligas con cobertura se cargan con **equipos reales**, los
**últimos partidos reales** (rachas BTTS / Over 2.5) y el análisis usa
goles reales de la temporada.

## 4) Ligas con datos en vivo (plan Free de football-data.org)

| Liga en la app | Código | En vivo |
|---|---|---|
| Premier League | PL | ✅ |
| LaLiga | PD | ✅ |
| Bundesliga (Alemania) | BL1 | ✅ |
| Eredivisie (Países Bajos) | DED | ✅ |
| Brasileirão Série A | BSA | ✅ |
| Serie A (Italia) | SA | ✅ |
| Ligue 1 (Francia) | FL1 | ✅ |
| Primeira Liga (Portugal) | PPL | ✅ |
| Resto (Ecuador, Argentina, México, MLS, etc.) | — | 🟡 demo |

> football-data.org Free solo cubre esas competiciones (además de
> Champions, Championship, Euro y Mundial). Las demás ligas de la app
> siguen funcionando en modo demo.

## 5) Endpoints del servidor

| Ruta | Qué devuelve |
|---|---|
| `/api/status` | Estado de la clave |
| `/api/competitions` | Competiciones disponibles |
| `/api/teams/{code}` | Equipos de la competición |
| `/api/matches/{code}` | Próximos partidos programados |
| `/api/finished/{code}` | Partidos terminados (últimos 150 días) ← rachas reales |

## 6) Problemas comunes

- **"FOOTBALL_DATA_API_KEY no está configurada"** → falta el paso 2.
- **Error 403** → clave incorrecta o vencida.
- **Error 429** → superaste las 10 peticiones/minuto del plan Free;
  espera un momento y recarga.
- **La píldora se queda en 🟡 con el .bat** → ciérralo y ábrelo de nuevo;
  si usaste la Opción B, cierra y repite en una ventana nueva de PowerShell.
